# Faker::Sports::Volleyball

```ruby
Faker::Sports::Volleyball.team #=> "Leo Shoes Modena"

Faker::Sports::Volleyball.player #=> "Saeid Marouf"

Faker::Sports::Volleyball.coach #=> "Russ Rose"

Faker::Sports::Volleyball.position #=> "Middle blocker"

Faker::Sports::Volleyball.formation #=> "4-2"
```
