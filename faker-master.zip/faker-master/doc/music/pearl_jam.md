# Faker::Music::PearlJam

```ruby
Faker::Music::PearlJam.musician #=> "Eddie Vedder"

Faker::Music::PearlJam.album #=> "Ten"

Faker::Music::PearlJam.song #=> "Jeremy"
```
