# Faker::Music::Rush

```ruby
Faker::Music::Rush.player #=> "Neil Peart"

Faker::Music::Rush.album #=> "Hold Your Fire"
```
