# Faker::Music::Opera

```ruby
Faker::Music::Opera.verdi #=> "Il Trovatore"

Faker::Music::Opera.rossini #=> "Il Barbiere di Siviglia"

Faker::Music::Opera.donizetti #=> "Lucia di Lammermoor"

Faker::Music::Opera.bellini #=> "Norma"

Faker::Music::Opera.mozart #=> "Die Zauberfloete"

Faker::Music::Opera.mozart_italian #=> "Cosi fan tutte"

Faker::Music::Opera.mozart_german #=> "Die Zauberfloete"

Faker::Music::Opera.gluck #=> "Orfeo ed Euridice"

Faker::Music::Opera.gluck_italian #=> "Orfeo ed Euridice"

Faker::Music::Opera.gluck_french #=> "Orphee et Euridice"

Faker::Music::Opera.beethoven #=> "Fidelio"

Faker::Music::Opera.weber #=> "Der Freischuetz"

Faker::Music::Opera.strauss #=> "Elektra"

Faker::Music::Opera.wagner #=> "Tristan und Isolde"

Faker::Music::Opera.schumann #=> "Genoveva"

Faker::Music::Opera.schubert #=> "Alfonso und Estrella"

Faker::Music::Opera.berg #=> "Wozzeck"

Faker::Music::Opera.ravel #=> "L'enfant et les sortileges"

Faker::Music::Opera.berlioz #=> "Les Troyens"

Faker::Music::Opera.bizet #=> "Carmen"

Faker::Music::Opera.gounod #=> "Faust"

Faker::Music::Opera.saint_saens #=> "Samson and Delilah"
```