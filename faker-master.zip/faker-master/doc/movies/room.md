# Faker::Movies::Room

```ruby
Faker::Movies::Room.actor #=> "Tommy Wiseau"

Faker::Movies::Room.character #=> "Johnny"

Faker::Movies::Room.location #=> "Johnny's Apartment"

Faker::Movies::Room.quote #=> "A-ha-ha-ha! What a story, Mark!"
```
