# Faker::Movie

```ruby
Faker::Movie.title #=> "The Lord of the Rings: The Two Towers"

Faker::Movie.quote #=> "Bumble bee tuna"
```
