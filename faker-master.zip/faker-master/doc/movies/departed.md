# Faker::Movies::Departed

Available since version next.

```ruby
Faker::Movies::Departed.actor #=> "Matt Damon"

Faker::Movies::Departed.character #=> "Frank Costello"

Faker::Movies::Departed.quote #=> "I'm the guy who does his job. You must be the other guy"
```
