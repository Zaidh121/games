# Faker::Appliance

Available since version 1.9.0.

```ruby
Faker::Appliance.brand #=> "Bosch"

Faker::Appliance.equipment #=> "Appliance plug"
```
