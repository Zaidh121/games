# Faker::NationalHealthService

```ruby
Faker::NationalHealthService.british_number #=> "403 958 5577"

# Keyword arguments: number
Faker::NationalHealthService.check_digit(number: 400_012_114) #=> 6
```
