# Faker::Nation

Available since version 1.9.0.

```ruby
# Random Nationality
Faker::Nation.nationality #=> "Nepalese"

# Random National Language
Faker::Nation.language #=> "Nepali"

# Random Capital City
Faker::Nation.capital_city #=> "Kathmandu"

# Random National Sport
Faker::Nation.national_sport #=> "dandi biyo"

# Random National Flag
Faker::Nation.flag #=> "🇫🇮"
