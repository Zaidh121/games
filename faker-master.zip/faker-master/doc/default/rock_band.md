# Faker::RockBand

```ruby
Faker::RockBand.name #=> "Led Zeppelin"
```
