# Faker::FunnyName

Available since version 1.8.0.

```ruby
Faker::FunnyName.name #=> "Sam Pull"

Faker::FunnyName.two_word_name #=> "Shirley Knot"

Faker::FunnyName.three_word_name #=> "Carson O. Gin"

Faker::FunnyName.four_word_name #=> "Maude L. T. Ford"

Faker::FunnyName.name_with_initial #=> "Heather N. Yonn"
```
