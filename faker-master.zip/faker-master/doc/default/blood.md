# Faker::Blood

Available since version 2.12.0.

```ruby
Faker::Blood.type #=> "AB"

Faker::Blood.rh_factor #=> "-"

Faker::Blood.group #=> "AB-"
```
