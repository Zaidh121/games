# Faker::Beer

Available since version 1.6.2.

```ruby
Faker::Beer.brand #=> "Heineken"

Faker::Beer.name #=> "Hercules Double IPA"

Faker::Beer.style #=> "Belgian Strong Ale"

Faker::Beer.hop #=> "Equinox"

Faker::Beer.yeast #=> "2278 - Czech Pils"

Faker::Beer.malts #=> "Rye malt"

Faker::Beer.ibu #=> "40 IBU"

Faker::Beer.alcohol #=> "6.3%"

Faker::Beer.blg #=> "18.5°Blg"
```
