# Faker::Verb

```ruby
Faker::Verb.base #=> "hurt"

Faker::Verb.past #=> "completed"

Faker::Verb.past_participle #=> "digested"

Faker::Verb.simple_present #=> "climbs"

Faker::Verb.ing_form #=> "causing"
```
