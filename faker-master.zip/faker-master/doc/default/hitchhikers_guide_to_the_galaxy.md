# Faker::HitchhikersGuideToTheGalaxy

Available since version 1.8.0.

```ruby
Faker::HitchhikersGuideToTheGalaxy.character #=> "Marvin"

Faker::HitchhikersGuideToTheGalaxy.location #=> "Arthur Dent's house"

Faker::HitchhikersGuideToTheGalaxy.marvin_quote #=> "Life? Don't talk to me about life."

Faker::HitchhikersGuideToTheGalaxy.planet #=> "Magrathea"

Faker::HitchhikersGuideToTheGalaxy.quote #=> "In the beginning, the Universe was created. This has made a lot of people very angry and been widely regarded as a bad move."

Faker::HitchhikersGuideToTheGalaxy.specie #=> "Perfectly Normal Beast"

Faker::HitchhikersGuideToTheGalaxy.starship #=> "Vogon Constructor Fleet"
```
