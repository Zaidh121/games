# Faker::Coffee

```ruby
Faker::Coffee.blend_name #=> "Summer Solstice"

Faker::Coffee.origin #=> "Antigua, Guatemala"

Faker::Coffee.variety #=> "Pacas"

Faker::Coffee.notes #=> "balanced, silky, marzipan, orange-creamsicle, bergamot"

Faker::Coffee.intensifier #=> "quick"
```
