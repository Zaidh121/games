# Faker::Construction

Available in future versions of faker

```ruby
# Random material
Faker::Construction.material #=> "Wood"

# Random subcontract category
Faker::Construction.subcontract_category #=> "Curb & Gutter"

# Random heavy_equipment
Faker::Construction.heavy_equipment #=> "Excavator"

# Random trade
Faker::Construction.trade #=> "Carpenter"

# Random standard_cost_code
Faker::Construction.standard_cost_code #=> "1-000 - Purpose"

# Random role
Faker::Construction.role #=> "Engineer"
```
