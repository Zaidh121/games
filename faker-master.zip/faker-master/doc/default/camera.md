# Faker::Camera

```ruby
Faker::Camera.brand #=> "Canon"

Faker::Camera.model #=> "450D"

Faker::Camera.brand_with_model #=> "Canon 450D"
```
