# Faker::Currency

```ruby
Faker::Currency.name #=> "Swedish Krona"

Faker::Currency.code #=> "USD"

Faker::Currency.symbol #=> "$"
```
