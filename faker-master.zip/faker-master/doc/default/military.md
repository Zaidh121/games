# Faker::Military

```ruby
Faker::Military.army_rank #=> "Staff Sergeant"

Faker::Military.marines_rank #=> "Gunnery Sergeant"

Faker::Military.navy_rank #=> "Seaman"

Faker::Military.air_force_rank #=> "Captain"

Faker::Military.space_force_rank #=> "Senior Enlisted Advisor of the Space Force"

Faker::Military.coast_guard_rank #=> "Master Chief Petty Officer of the Coast Guard"

Faker::Military.dod_paygrade #=> "E-6"
```
