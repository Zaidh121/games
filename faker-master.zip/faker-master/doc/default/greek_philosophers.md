# Faker::GreekPhilosophers

Available since version 1.9.0.

```ruby
Faker::GreekPhilosophers.name #=> "Socrates"

Faker::GreekPhilosophers.quote #=> "Only the educated are free."
```
