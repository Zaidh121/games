# Faker::Boolean

Available since version 1.6.2.

```ruby
Faker::Boolean.boolean #=> true

# Keyword parameter: true_ratio
Faker::Boolean.boolean(true_ratio: 0.2) #=> false
```
