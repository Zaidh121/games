# Faker::House

```ruby
Faker::House.furniture #=> "chair"

Faker::House.room #=> "kitchen"
```
