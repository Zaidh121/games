# Faker::TvShows::Stargate

```ruby
Faker::TvShows::Stargate.character #=> "Jack O'Neill"

Faker::TvShows::Stargate.planet #=> "Abydos"

Faker::TvShows::Stargate.quote #=> "General, request permission to beat the crap out of this man."
```
