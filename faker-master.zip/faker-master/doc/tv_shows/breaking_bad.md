# Faker::TvShows::BreakingBad

Available since version 1.8.8.

```ruby
Faker::TvShows::BreakingBad.character #=> "Walter White"

Faker::TvShows::BreakingBad.episode #=> "Cancer Man"
```
