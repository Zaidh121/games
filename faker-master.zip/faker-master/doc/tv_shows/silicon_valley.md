# Faker::TvShows::SiliconValley

```ruby
Faker::TvShows::SiliconValley.character # => "Jian Yang"

Faker::TvShows::SiliconValley.company # => "Bachmanity"

Faker::TvShows::SiliconValley.quote # => "I don't want to live in a world where someone else is making the world a better place better than we are."

Faker::TvShows::SiliconValley.app # => "Nip Alert"

Faker::TvShows::SiliconValley.invention # => "Tres Comas Tequila"

Faker::TvShows::SiliconValley.motto # => "Our products are products, producing unrivaled results"

Faker::TvShows::SiliconValley.url # => "http://www.piedpiper.com"

Faker::TvShows::SiliconValley.email #=> "richard@piedpiper.test"
```