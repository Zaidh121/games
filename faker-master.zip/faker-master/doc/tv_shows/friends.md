# Faker::TvShows::Friends

Available since version 1.7.3.

```ruby
Faker::TvShows::Friends.character #=> "Rachel Green"

Faker::TvShows::Friends.location #=> "Central Perk"

Faker::TvShows::Friends.quote #=> "We were on a break!"
```
