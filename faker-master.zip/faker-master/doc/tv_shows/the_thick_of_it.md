# Faker::TvShows::TheThickOfIt

```ruby
Faker::TvShows::TheThickOfIt.character #=> "Nicola Murray"

Faker::TvShows::TheThickOfIt.department #=> "Shadow Cabinet"

Faker::TvShows::TheThickOfIt.position #=> "Director of Communications"
```
