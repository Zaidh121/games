# Faker::TvShows::BigBangTheory

```ruby
Faker::TvShows::BigBangTheory.character #=> "Sheldon Cooper"

Faker::TvShows::BigBangTheory.quote #=> "I'm not crazy. My mother had me tested."
```
