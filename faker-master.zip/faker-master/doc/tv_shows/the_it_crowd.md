# Faker::TvShows::TheITCrowd

```ruby
Faker::TvShows::TheITCrowd.actor #=> "Chris O'Dowd"

Faker::TvShows::TheITCrowd.character #=> "Roy Trenneman"

Faker::TvShows::TheITCrowd.email #=> "roy.trenneman@reynholm.test"

Faker::TvShows::TheITCrowd.quote #=> "Hello, IT. Have you tried turning it off and on again?"
```
