# Faker::TvShows::NewGirl

```ruby
Faker::TvShows::NewGirl.character #=> "Jessica Day"

Faker::TvShows::NewGirl.quote #=> "Are you cooking a frittata in a sauce pan? What is this – prison?"
```
