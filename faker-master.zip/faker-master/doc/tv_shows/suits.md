# Faker::TvShows::Suits

```ruby
Faker::TvShows::Suits.character #=> "Harvey Specter"
Faker::TvShows::Suits.quote #=> "Don't play the odds, play the man."
```
