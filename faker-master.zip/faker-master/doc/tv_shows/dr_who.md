# Faker::TvShows::DrWho

```ruby
Faker::TvShows::DrWho.character    #=> "Captain Jack Harkness"

Faker::TvShows::DrWho.the_doctor   #=> "Ninth Doctor"

Faker::TvShows::DrWho.actor        #=> "Matt Smith"

Faker::TvShows::DrWho.catch_phrase #=> "Fantastic!"

Faker::TvShows::DrWho.quote        #=> "Lots of planets have a north!"

Faker::TvShows::DrWho.villain      #=> "The Master"

Faker::TvShows::DrWho.specie       #=> "Dalek"
```
