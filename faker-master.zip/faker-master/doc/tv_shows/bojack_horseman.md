# Faker::TvShows::BojackHorseman

```ruby
Faker::TvShows::BojackHorseman.character #=> "BoJack Horseman""

Faker::TvShows::BojackHorseman.tongue_twister #=> "Did you steal a meal from Neal McBeal the Navy Seal?"

Faker::TvShows::BojackHorseman.quote #=> "Not understanding that you're a horrible person doesn't make you less of a horrible person"
```
