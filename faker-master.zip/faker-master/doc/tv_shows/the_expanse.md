# Faker::TvShows::TheExpanse

```ruby
Faker::TvShows::TheExpanse.character #=> "Jim Holden"

Faker::TvShows::TheExpanse.location #=> "Ganymede"

Faker::TvShows::TheExpanse.ship #=> "Nauvoo"

Faker::TvShows::TheExpanse.quote #=> "I am that guy."
```
