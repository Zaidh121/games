# Faker::TvShows::VentureBros

```ruby
Faker::TvShows::VentureBros.character #=> "Scaramantula"

Faker::TvShows::VentureBros.vehicle #=> "Monarchmobile"

Faker::TvShows::VentureBros.organization #=> "Guild of Calamitous Intent"

Faker::TvShows::VentureBros.quote #=> "Revenge like gazpacho soup, is best served cold, precise and merciless."
```
