# Faker::TvShows::Buffy

```ruby
Faker::TvShows::Buffy.character #=> "Buffy Summers"

Faker::TvShows::Buffy.quote #=> "If the apocalypse comes, beep me."

Faker::TvShows::Buffy.actor #=> "John Ritter"

Faker::TvShows::Buffy.big_bad #=> "Glory"

Faker::TvShows::Buffy.episode #> "Once More, with Feeling"
```
