# Faker::Blockchain::Aeternity

```ruby
Faker::Blockchain::Aeternity.address #=> "ak_zvU8YQLagjcfng7Tg8yCdiZ1rpiWNp1PBn3vtUs44utSvbJVR"

Faker::Blockchain::Aeternity.transaction #=> "th_147nDP22h3pHrLt2qykTH4txUwQh1ccaXp"

Faker::Blockchain::Aeternity.contract #=> "ct_Hk2JsNeWGEYQEHHQCfcBeGrwbhtYSwFTPdDhW2SvjFYVojyhW"

Faker::Blockchain::Aeternity.oracle #=> "ok_28QDg7fkF5qiKueSdUvUBtCYPJdmMEoS73CztzXCRAwMGKHKZh"

```
