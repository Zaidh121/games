# Faker::Fantasy::Tolkien

```ruby
# Any character from the entire Tolkien legendarium
Faker::Fantasy::Tolkien.character #=> "Bungo Baggins"

# Any location from the entire Tolkien legendarium
Faker::Fantasy::Tolkien.location #=> "Minas Morgul"

# Any poem title from the entire Tolkien legendarium
Faker::Fantasy::Tolkien.poem #=> "Fifteen birds in five fir trees"

# Any race from the entire Tolkien legendarium
Faker::Fantasy::Tolkien.race #=> "Ents"
```
