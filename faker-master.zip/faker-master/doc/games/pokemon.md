# Faker::Games::Pokemon

Available since version 1.7.0.

```ruby
Faker::Games::Pokemon.name #=> "Pikachu"

Faker::Games::Pokemon.location #=> "Pallet Town"

Faker::Games::Pokemon.move #=> "Thunder Shock"
```
