# Faker::Games::HalfLife

```ruby
# Any character from the game
Faker::Games::HalfLife.character #=> "Gordon Freeman"

# Any enemy from the game
Faker::Games::HalfLife.enemy #=> "Houndeye"

# Any location from the game
Faker::Games::HalfLife.location #=> "Black Mesa Research Facility"
```
