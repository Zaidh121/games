# Faker::Games::DnD

```ruby
Faker::Games::DnD.alignment #=> "Lawful Neutral"

Faker::Games::DnD.background #=> "Urchin"

Faker::Games::DnD.city #=> "Earthfast"

Faker::Games::DnD.first_name #=> "Celestine"

Faker::Games::DnD.klass #=> "Warlock"

Faker::Games::DnD.language #=> "Gnomish"

Faker::Games::DnD.last_name #=> "Nightbreeze"

Faker::Games::DnD.melee_weapon #=> "Handaxe"

Faker::Games::DnD.monster #=> "Manticore"

Faker::Games::DnD.name #=> "Drust Silverveil"

Faker::Games::DnD.race #=> "Dwarf"

Faker::Games::DnD.ranged_weapon #=> "Shortbow"

Faker::Games::DnD.title_name #=> "Selene the Dreamer"
```
