# Faker::Games::Heroes

```ruby
Faker::Games::Heroes.name #=> "Christian"

Faker::Games::Heroes.specialty #=> "Ballista"

Faker::Games::Heroes.klass #=> "Knight"

Faker::Games::Heroes.artifact #=> "Armageddon's Blade"
```
