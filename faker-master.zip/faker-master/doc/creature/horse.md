# Faker::Creature::Horse

```ruby
Faker::Creature::Horse.name #=> "Noir"

Faker::Creature::Horse.breed #=> "Spanish Barb see Barb Horse"
```
