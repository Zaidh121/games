# Faker::Creature::Dog

```ruby
# Random dog name
Faker::Creature::Dog.name #=> "Spike"

# Random dog breed
Faker::Creature::Dog.breed #=> "Yorkshire Terrier"

# Random dog sound
Faker::Creature::Dog.sound #=> "woof woof"

# Random dog meme phrase
Faker::Creature::Dog.meme_phrase #=> "smol pupperino"

# Random dog age
Faker::Creature::Dog.age #=> "puppy"

# Random dog gender
Faker::Creature::Dog.gender #=> "female"

# Random dog coat length
Faker::Creature::Dog.coat_length #=> "short"

# Random dog size
Faker::Creature::Dog.size #=> "small"
```
