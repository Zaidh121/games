# Faker::JapaneseMedia::Naruto

```ruby
Faker::JapaneseMedia::Naruto.character #=> "Naruto Uzumaki"

Faker::JapaneseMedia::Naruto.village #=> "Konohagakure (Leaf Village)"

Faker::JapaneseMedia::Naruto.eye #=> "Konohagakure (Byakugan)"

Faker::JapaneseMedia::Naruto.demon #=> "Nine-Tails (Kurama)"
```