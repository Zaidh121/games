# Faker::JapaneseMedia::FmaBrotherhood

```ruby
Faker::JapaneseMedia::FmaBrotherhood.character #=> "Edward Elric"

Faker::JapaneseMedia::FmaBrotherhood.city #=> "Central City"

Faker::JapaneseMedia::FmaBrotherhood.country #=> "Xing"
```
