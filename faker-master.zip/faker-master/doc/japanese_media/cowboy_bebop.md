# Faker::JapaneseMedia::CowboyBebop

Available since version @faker.version next

```ruby
Faker::JapaneseMedia::CowboyBebop.character #=> "Spike Spiegel"
Faker::JapaneseMedia::CowboyBebop.episode #=> "Honky Tonk Women"
Faker::JapaneseMedia::CowboyBebop.songs #=> "Live in Baghdad"
Faker::JapaneseMedia::CowboyBebop.quote #=> "Bang!"
```