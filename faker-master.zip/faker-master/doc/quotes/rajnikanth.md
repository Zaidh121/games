# Faker::Quotes::Rajnikanth

```ruby
Faker::Quotes::Rajnikanth.joke #=> "Rajinikanth can get rid of his shadow"
```